#!/usr/bin/env sh
# 将 Android 应用枚举辅助 DEX 追加到已压缩的模块包；不构建或安装 APK。
# 用法: sh .github/scripts/complete-module.sh <模块包> <classes.dex>
set -eu
[ "$#" -eq 2 ]
module="$(CDPATH= cd -- "$(dirname -- "$1")" && pwd)/$(basename -- "$1")"
[ -s "$module" ]
[ -s "$2" ]
stage="$(mktemp -d)"
trap 'rm -rf "$stage"' EXIT HUP INT TERM
mkdir -p "$stage/bin"
cp "$2" "$stage/bin/android-platform.dex"
(cd "$stage" && 7z a -tzip -mx=0 "$module" bin/android-platform.dex)
7z t "$module"
