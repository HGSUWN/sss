#!/usr/bin/env sh
# 文件: tests/customize_hot_update_test.sh
# 功能: 验证安装选择、当前数据快照、热切换互斥和失败恢复。
# 用法: sh tests/customize_hot_update_test.sh [netproxyctl 测试程序]
# 依赖: POSIX sh、awk、sed、mktemp；Linux 锁测试需要 flock。

set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
CUSTOMIZE="$ROOT/src/module/customize.sh"
NATIVE_CTL="${1:-}"
WORKDIR="$(mktemp -d)"
trap 'rm -rf "$WORKDIR"' EXIT HUP INT TERM
LIVE="$WORKDIR/modules/netproxy"
LIVE_DIR="$LIVE"
STAGE="$WORKDIR/modules_update/netproxy"
FUNCTIONS="$WORKDIR/functions.sh"
CALL_LOG="$WORKDIR/calls"
export CALL_LOG

# 只替换测试状态目录；所有被测函数直接取自生产脚本。
awk '
  /^readonly / { print }
  /^print_title\(\)/ { emit = 1 }
  /^if \[ "\$BACKGROUND" = true \]; then/ { exit }
  emit { print }
' "$CUSTOMIZE" | sed "s@/dev/netproxy@$WORKDIR/state@g" > "$FUNCTIONS"
. "$FUNCTIONS"

ui_print() { printf '%s\n' "$*"; }
chown() { :; }
chcon() { :; }
pidof() { [ "${TEST_RUNNING:-false}" = true ]; }
su() { [ "$1" = -c ]; sh -c "$2"; }

# 参数: $1 快照来源标签，用于区分当前与待安装配置。
# 返回: 0=输出不含真实凭据的 eBPF 入站 JSON。
inbound_fixture() {
  local timeout
  case "$1" in
    package) timeout=10m ;;
    latest) timeout=15m ;;
    *) timeout=5m ;;
  esac
  printf '{"backend":"ebpf","root_policy":"default","app":{"enabled":true,"mode":"blacklist","proxy_apps":[],"bypass_apps":[]},"ebpf":{"type":"ebpf","tag":"netproxy-in","udp_timeout":"%s","local":{"enabled":true},"shared":{"enabled":false}}}\n' "$timeout"
}

# 参数: $1 快照来源标签，用于区分当前与待安装配置。
# 返回: 0=输出不含真实凭据的模块 JSON。
module_fixture() {
  local auto_start=false
  [ "$1" = current ] && auto_start=true
  printf '{"auto_start":%s,"selection":{"group_id":"default"}}\n' "$auto_start"
}

write_module() {
  target="$1" label="$2"
  mkdir -p "$target/bin" "$target/config/inbound" "$target/config/singbox/rules/local" \
    "$target/config/singbox/rules/remote" "$target/config/singbox/custom-state" \
    "$target/data/catalog/default" "$target/runtime" "$target/logs"
  printf 'id=netproxy\nversion=%s\n' "$label" > "$target/module.prop"
  module_fixture "$label" > "$target/config/module.json"
  inbound_fixture "$label" > "$target/config/inbound/inbound.json"
  printf '%s\n' "$label-config" > "$target/config/singbox/config.json"
  printf '%s\n' "$label-local" > "$target/config/singbox/rules/local/custom.json"
  printf '%s\n' "$label-remote" > "$target/config/singbox/rules/remote/test.srs"
  printf '%s\n' "$label-cache" > "$target/config/singbox/cache.db"
  printf '%s\n' "$label-state" > "$target/config/singbox/custom-state/state.json"
  printf '%s\n' "$label-meta" > "$target/data/catalog/default/meta.json"
  printf '%s\n' "$label-provider" > "$target/data/catalog/default/provider.json"
  printf '%s\n' "$label-history" > "$target/data/catalog/default/history.jsonl"
  printf '%s\n' "$label-log" > "$target/logs/service.log"
  printf '%s\n' "$label-runtime" > "$target/runtime/providers.json"
  printf '%s\n' '#!/bin/sh' \
    'printf "%s\n" "$*" >> "$CALL_LOG"' \
    'case "$1:$2:$3" in' \
    '  __internal:worker:stop) exit "${TEST_WORKER_STOP:-0}" ;;' \
    '  __internal:migrate-legacy:--module-dir) exit "${TEST_MIGRATE:-0}" ;;' \
    '  service:stop:) exit "${TEST_SERVICE_STOP:-0}" ;;' \
    '  config:check:) exit "${TEST_CONFIG_CHECK:-0}" ;;' \
    '  api:init:) exit "${TEST_API_INIT:-0}" ;;' \
    'esac' > "$target/bin/netproxyctl"
  cp "$target/bin/netproxyctl" "$target/netproxyctl"
  printf '%s\n' 'core fixture' > "$target/bin/sing-box"
  printf '%s\n' 'anonymous dex fixture' > "$target/bin/android-platform.dex"
  for file in service.sh action.sh uninstall.sh; do
    printf '%s\n' '#!/bin/sh' > "$target/$file"
  done
  chmod +x "$target/bin/netproxyctl" "$target/netproxyctl"
}

reset_modules() {
  rm -rf "$WORKDIR/modules" "$WORKDIR/modules_update" "$WORKDIR/state"
  write_module "$STAGE" package
  write_module "$LIVE" current
  mkdir -p "$LIVE/data/catalog/staging" "$LIVE/data/catalog/subscription"
  printf '%s\n' 'temporary' > "$LIVE/data/catalog/staging/download.tmp"
  printf '%s\n' 'subscription-meta' > "$LIVE/data/catalog/subscription/meta.json"
  printf '%s\n' 'subscription-provider' > "$LIVE/data/catalog/subscription/provider.json"
  : > "$LIVE/update"
  : > "$CALL_LOG"
  MODPATH="$STAGE"
  INSTALL_MODE=preserve
  PROXY_WAS_RUNNING=false
  SERVICE_STOPPED=false
  KEY_PID=""
  TEST_RUNNING=false
  unset TEST_WORKER_STOP TEST_SERVICE_STOP TEST_CONFIG_CHECK TEST_PIDOF TEST_API_INIT TEST_MIGRATE
}

assert_value() { grep -Fxq "$2" "$1"; }
# 参数: $1 入站文件，$2 快照来源接口名。
# 返回: 0=JSON 快照匹配，1=内容不一致或文件不可读。
assert_inbound() { assert_value "$1" "$(inbound_fixture "$2")"; }
# 参数: $1 模块文件，$2 快照来源节点 tag。
# 返回: 0=JSON 快照匹配，1=内容不一致或文件不可读。
assert_module() { assert_value "$1" "$(module_fixture "$2")"; }

# 参数: $1 等待秒数。
# 返回: 0=写入下一个测试按键，1=模拟读取失败。
next_test_key() {
  printf '%s\n' "$1" >> "$WORKDIR/timeouts"
  VOLUME_KEY="${CHOICES%% *}"
  if [ "$CHOICES" = "$VOLUME_KEY" ]; then CHOICES=timeout; else CHOICES="${CHOICES#* }"; fi
  [ "$VOLUME_KEY" != error ]
}

test_title_spacing() (
  for title in '选择安装方式' '准备安装' '准备安装模块' '安装模块' '安装完成'; do
    { print_title "$title"; print_step '内容'; } > "$WORKDIR/title"
    awk '
      NR == 1 || NR == 5 { if ($0 != "") exit 1 }
      NR == 2 { border = $0 }
      NR == 4 { if ($0 != border) exit 1 }
      NR == 6 { if ($0 != "▶ 内容") exit 1 }
      END { if (NR != 6) exit 1 }
    ' "$WORKDIR/title"
  done
)

test_install_choices() (
  reset_modules
  wait_volume_key() { next_test_key "$@"; }
  for pair in 'timeout:preserve' 'down:preserve' 'up down:nodes' \
    'up up down down:fresh' 'up up up down:preserve' 'up up down up down:preserve'; do
    CHOICES="${pair%:*}"
    choose_install_mode > "$WORKDIR/menu"
    [ "$INSTALL_MODE" = "${pair##*:}" ]
    [ "$(sed -n '5p' "$WORKDIR/menu")" = '' ]
    [ "$(sed -n '6p' "$WORKDIR/menu")" = '  1. 保留现有数据（默认）' ]
    grep -Fq '[音量+] 循环选择  [音量-] 确认' "$WORKDIR/menu"
  done
  for CHOICES in 'up timeout' 'up up timeout' 'up up down timeout' 'up up down up timeout' 'error'; do
    if choose_install_mode > "$WORKDIR/menu"; then
      printf '%s\n' '操作后超时不能自动确认安装' >&2
      exit 1
    fi
    assert_module "$LIVE/config/module.json" current
  done
  rm "$LIVE/config/singbox/config.json"
  CHOICES=timeout
  if choose_install_mode > "$WORKDIR/menu"; then exit 1; fi
  CHOICES='up down'
  choose_install_mode > "$WORKDIR/menu"
  [ "$INSTALL_MODE" = nodes ]
  rm -rf "$LIVE"
  CHOICES=timeout
  choose_install_mode > "$WORKDIR/menu"
  [ "$INSTALL_MODE" = fresh ]
  grep -qx 10 "$WORKDIR/timeouts"
  grep -qx 20 "$WORKDIR/timeouts"
)

test_key_events() (
  reset_modules
  INSTALL_TMP="$WORKDIR"
  printf '%s\n' \
    '/dev/input/event0: EV_KEY KEY_VOLUMEUP UP' \
    '/dev/input/event0: EV_KEY KEY_VOLUMEUP REPEAT' \
    '/dev/input/event0: EV_KEY KEY_VOLUMEUP DOWN                ' \
    '/dev/input/event0: EV_KEY KEY_VOLUMEUP UP' \
    '/dev/input/event0: EV_KEY KEY_VOLUMEDOWN 00000001            ' > "$INSTALL_TMP/keys"
  sleep 60 &
  KEY_PID=$!
  trap stop_key_listener EXIT
  KEY_FD=9
  exec 9<"$INSTALL_TMP/keys"
  wait_volume_key 1
  [ "$VOLUME_KEY" = up ]
  wait_volume_key 1
  [ "$VOLUME_KEY" = down ]
  sleep() { :; }
  wait_volume_key 1
  [ "$VOLUME_KEY" = timeout ]
  stop_key_listener
  [ -z "$KEY_PID" ]
)

test_key_output_descriptor() (
  reset_modules
  INSTALL_TMP="$WORKDIR"
  OUTFD=9
  exec 9>"$WORKDIR/installer-output"
  getevent() { :; }
  sleep() { :; }
  wait_volume_key 1
  [ "$KEY_FD" = 8 ]
  stop_key_listener
  stop_key_listener
  printf '%s\n' 'installer-output' >&9
  exec 9>&-
  assert_value "$WORKDIR/installer-output" installer-output
)

test_snapshot_modes() (
  for INSTALL_MODE in preserve nodes fresh; do
    mode="$INSTALL_MODE"
    reset_modules
    INSTALL_MODE="$mode"
    copy_user_data_locked
    if [ "$mode" = fresh ]; then
      assert_value "$STAGE/data/catalog/default/provider.json" package-provider
      assert_value "$STAGE/logs/service.log" package-log
    else
      assert_value "$STAGE/data/catalog/default/provider.json" current-provider
      assert_value "$STAGE/data/catalog/subscription/provider.json" subscription-provider
      assert_value "$STAGE/data/catalog/default/history.jsonl" current-history
      assert_value "$STAGE/logs/service.log" current-log
    fi
    if [ "$mode" = preserve ]; then
      assert_inbound "$STAGE/config/inbound/inbound.json" current
      assert_module "$STAGE/config/module.json" current
      assert_value "$STAGE/config/singbox/config.json" current-config
      assert_value "$STAGE/config/singbox/rules/local/custom.json" current-local
      assert_value "$STAGE/config/singbox/cache.db" current-cache
      assert_value "$STAGE/config/singbox/custom-state/state.json" current-state
      [ ! -e "$STAGE/config/telemetry" ]
      grep -Fq '__internal migrate-legacy --module-dir' "$CALL_LOG"
    else
      assert_inbound "$STAGE/config/inbound/inbound.json" package
      assert_module "$STAGE/config/module.json" package
      assert_value "$STAGE/config/singbox/rules/local/custom.json" package-local
      assert_value "$STAGE/config/singbox/cache.db" package-cache
      assert_value "$STAGE/config/singbox/custom-state/state.json" package-state
      [ ! -e "$STAGE/config/telemetry" ]
    fi
    assert_value "$STAGE/config/singbox/rules/remote/test.srs" package-remote
    assert_value "$STAGE/runtime/providers.json" package-runtime
    [ ! -e "$STAGE/data/catalog/staging/download.tmp" ]
    [ -z "$(find "$STAGE" -name '.install-state.*' -print)" ]
  done
)


test_legacy_migration_failure() (
  reset_modules
  TEST_MIGRATE=1
  export TEST_MIGRATE
  if copy_user_data_locked; then exit 1; fi
  assert_module "$LIVE/config/module.json" current
  assert_module "$STAGE/config/module.json" package
  [ -z "$(find "$STAGE" -name '.install-state.*' -print)" ]
)

test_snapshot_failure() (
  reset_modules
  cp() { return 1; }
  if copy_user_data_locked; then exit 1; fi
  assert_module "$STAGE/config/module.json" package
  assert_value "$LIVE/data/catalog/default/provider.json" current-provider
)

test_snapshot_rename_failure() (
  reset_modules
  mv() {
    case "$1" in */current/data/catalog) return 1 ;; esac
    command mv "$@"
  }
  if copy_user_data_locked; then exit 1; fi
  assert_module "$STAGE/config/module.json" package
  assert_inbound "$STAGE/config/inbound/inbound.json" package
  assert_value "$STAGE/config/singbox/cache.db" package-cache
  [ -z "$(find "$STAGE" -name '.install-state.*' -print)" ]
)

test_missing_current_data() (
  reset_modules
  rm "$LIVE/config/singbox/config.json"
  if copy_user_data_locked; then exit 1; fi
  assert_module "$STAGE/config/module.json" package
  INSTALL_MODE=nodes
  copy_user_data_locked
  assert_value "$STAGE/config/singbox/config.json" package-config
  mkdir -p "$LIVE/runtime/.config-apply"
  if copy_user_data_locked; then exit 1; fi
)

# 参数: 无。
# 返回: 0=缺失入站时安装模式与包校验符合契约，非零=回归失败。
test_missing_inbound() (
  reset_modules
  rm -rf "$LIVE/config/inbound"
  wait_volume_key() { VOLUME_KEY=timeout; }
  if choose_install_mode > "$WORKDIR/menu"; then exit 1; fi
  grep -Fq 'config/inbound/inbound.json' "$WORKDIR/menu"
  grep -Fq '请选择仅保留节点与订阅或全新安装' "$WORKDIR/menu"
  if copy_user_data_locked; then exit 1; fi
  assert_inbound "$STAGE/config/inbound/inbound.json" package
  for mode in nodes fresh; do
    INSTALL_MODE="$mode"
    if command -v flock >/dev/null 2>&1; then
      with_user_data_locks commit_hot_update
      assert_inbound "$LIVE/config/inbound/inbound.json" package
      if [ "$mode" = nodes ]; then
        assert_value "$LIVE/data/catalog/default/provider.json" current-provider
        assert_value "$LIVE/logs/service.log" current-log
      else
        assert_value "$LIVE/data/catalog/default/provider.json" package-provider
      fi
    else
      copy_user_data_locked
      assert_inbound "$STAGE/config/inbound/inbound.json" package
    fi
    reset_modules
    rm -rf "$LIVE/config/inbound"
  done
  rm "$STAGE/config/inbound/inbound.json"
  if validate_stage; then exit 1; fi
)

# 参数: 无。
# 返回: 0=缺失模块 JSON 时仅 nodes/fresh 可安装，非零=回归失败。
test_missing_module() (
  reset_modules
  rm "$LIVE/config/module.json"
  wait_volume_key() { VOLUME_KEY=timeout; }
  if choose_install_mode > "$WORKDIR/menu"; then exit 1; fi
  grep -Fq 'config/module.json' "$WORKDIR/menu"
  grep -Fq '请选择仅保留节点与订阅或全新安装' "$WORKDIR/menu"
  if copy_user_data_locked; then exit 1; fi
  assert_module "$STAGE/config/module.json" package
  for mode in nodes fresh; do
    INSTALL_MODE="$mode"
    copy_user_data_locked
    assert_module "$STAGE/config/module.json" package
  done
  rm "$STAGE/config/module.json"
  if validate_stage; then exit 1; fi
)

test_permissions() (
  reset_modules
  set_permissions
  case "$(uname -s)" in
    MINGW*|MSYS*) printf '%s\n' 'NTFS 权限位不作断言，权限断言需在 Linux 执行' ;;
    *)
      for file in config/module.json config/inbound/inbound.json data/catalog/default/provider.json logs/service.log; do
        [ "$(stat -c '%a' "$STAGE/$file")" = 600 ]
      done
      [ "$(stat -c '%a' "$STAGE/config")" = 700 ]
      [ "$(stat -c '%a' "$STAGE/service.sh")" = 755 ]
      ;;
  esac
  chcon() { return 1; }
  if set_permissions; then exit 1; fi
)

test_service_failures() (
  reset_modules
  TEST_RUNNING=true
  TEST_WORKER_STOP=1
  export TEST_WORKER_STOP
  if stop_proxy_if_running; then exit 1; fi
  [ "$(wc -l < "$CALL_LOG")" -eq 1 ]
  restore_live_service
  grep -q '^service start$' "$CALL_LOG"
  reset_modules
  TEST_SERVICE_STOP=1
  export TEST_SERVICE_STOP
  if stop_proxy_if_running; then exit 1; fi
  restore_live_service
  grep -q '^__internal worker start' "$CALL_LOG"
  ! grep -q '^service start$' "$CALL_LOG"
)

test_hot_update() (
  for mode in preserve nodes fresh; do
    reset_modules
      INSTALL_MODE="$mode"
    INSTALLER_PID=99999999
    sleep() { :; }
    with_user_data_locks() {
      CATALOG_LOCK=data/.catalog.netproxy-test.lock
      for entry in config/inbound/inbound.json.lock config/module.json.lock config/singbox/config.json.lock "$CATALOG_LOCK"; do
        : > "$LIVE/$entry"
      done
      "$@"
    }
    apply_hot_update
    [ ! -e "$STAGE" ] && [ ! -e "$LIVE/update" ]
    assert_value "$LIVE/module.prop" version=package
    grep -Fq '后台热更新已完成' "$LIVE/logs/service.log"
    grep -q '^__internal worker start' "$CALL_LOG"
    grep -Fxq 'api init' "$CALL_LOG"
    [ -z "$(find "$WORKDIR/modules" -name '.netproxy.install-backup.*' -print)" ]
  done
)

test_hot_update_guards() (
  reset_modules
  INSTALLER_PID="$$"
  sleep() { :; }
  if apply_hot_update; then exit 1; fi
  assert_value "$LIVE/module.prop" version=current
  [ ! -s "$CALL_LOG" ]
  INSTALLER_PID=99999999
  rm "$LIVE/update"
  if apply_hot_update; then exit 1; fi
  assert_value "$LIVE/module.prop" version=current
  : > "$LIVE/update"
  rm "$STAGE/bin/sing-box"
  if apply_hot_update; then exit 1; fi
  [ -d "$STAGE" ] && [ -f "$LIVE/update" ]

  reset_modules
  TEST_API_INIT=1
  export TEST_API_INIT
  if commit_hot_update; then exit 1; fi
  assert_value "$CALL_LOG" 'api init'
  [ "$(wc -l < "$CALL_LOG")" -eq 2 ]
  grep -Fq '__internal migrate-legacy --module-dir' "$CALL_LOG"
  assert_value "$LIVE/module.prop" version=current
  assert_module "$LIVE/config/module.json" current
  [ -d "$STAGE" ] && [ -f "$LIVE/update" ]
)

test_hot_update_latest_data() (
  reset_modules
  copy_user_data_locked
  assert_module "$STAGE/config/module.json" current
  INSTALLER_PID=99999999
  sleep() {
    module_fixture latest > "$LIVE/config/module.json"
    printf '%s\n' 'latest-provider' > "$LIVE/data/catalog/default/provider.json"
  }
  with_user_data_locks() {
    CATALOG_LOCK=data/.catalog.netproxy-test.lock
    for entry in config/inbound/inbound.json.lock config/module.json.lock config/singbox/config.json.lock "$CATALOG_LOCK"; do
      : > "$LIVE/$entry"
    done
    "$@"
  }
  apply_hot_update
  assert_module "$LIVE/config/module.json" latest
  assert_value "$LIVE/data/catalog/default/provider.json" latest-provider

  reset_modules
  rm "$LIVE/config/singbox/config.json"
  if apply_hot_update; then exit 1; fi
  restore_live_service
  [ -d "$STAGE" ] && [ -f "$LIVE/update" ]
  assert_value "$LIVE/data/catalog/default/provider.json" latest-provider
  grep -q '^__internal worker start' "$CALL_LOG"
)

test_hot_rename_failure() (
  reset_modules
  CATALOG_LOCK=data/.catalog.netproxy-test.lock
  for entry in config/inbound/inbound.json.lock config/module.json.lock config/singbox/config.json.lock "$CATALOG_LOCK"; do
    : > "$LIVE/$entry"
  done
  mv() {
    [ "$1" != "$STAGE" ] || return 1
    command mv "$@"
  }
  if commit_hot_update; then exit 1; fi
  assert_value "$LIVE/module.prop" version=current
  assert_inbound "$LIVE/config/inbound/inbound.json" current
  [ -f "$LIVE/update" ] && [ -d "$STAGE" ]
)

test_linux_locks() (
  command -v flock >/dev/null 2>&1 || {
    printf '%s\n' '当前 Shell 无 flock，互斥测试需在 Linux 执行'
    exit 0
  }
  reset_modules
  with_user_data_locks copy_user_data_locked
  catalog_lock="$(find "$LIVE/data" -name '.catalog.netproxy-*.lock')"
  inode="$(stat -c '%i' "$catalog_lock")"
  config_inode="$(stat -c '%i' "$LIVE/config/module.json.lock")"
  inbound_inode="$(stat -c '%i' "$LIVE/config/inbound/inbound.json.lock")"
  for busy in "$catalog_lock" "$LIVE/config/module.json.lock" "$LIVE/config/inbound/inbound.json.lock" "$WORKDIR/state/service.lock.flock"; do
    (
      exec 3>"$busy"
      flock -n 3 3>&3
      if with_user_data_locks commit_hot_update; then exit 1; fi
      assert_value "$LIVE/module.prop" version=current
    )
  done
  group_lock="$LIVE/data/.catalog.netproxy-group.lock"
  (
    exec 3>"$group_lock"
    flock -n 3 3>&3
    if with_user_data_locks commit_hot_update; then exit 1; fi
  )
  with_user_data_locks commit_hot_update
  [ "$(stat -c '%i' "$LIVE/data/${catalog_lock##*/}")" = "$inode" ]
  [ "$(stat -c '%i' "$LIVE/config/module.json.lock")" = "$config_inode" ]
  [ "$(stat -c '%i' "$LIVE/config/inbound/inbound.json.lock")" = "$inbound_inode" ]
  [ -f "$LIVE/data/${group_lock##*/}" ]
)

test_native_catalog_lock() (
  [ -n "$NATIVE_CTL" ] && command -v flock >/dev/null 2>&1 || exit 0
  reset_modules
  cp "$ROOT/src/module/config/module.json" "$LIVE/config/module.json"
  cp "$ROOT/src/module/config/inbound/inbound.json" "$LIVE/config/inbound/inbound.json"
  cp "$ROOT/src/module/data/catalog/default/meta.json" "$LIVE/data/catalog/default/meta.json"
  cp "$ROOT/src/module/data/catalog/default/provider.json" "$LIVE/data/catalog/default/provider.json"
  rm -rf "$LIVE/data/catalog/subscription"
  native_must_wait() {
    if NETPROXY_MODULE_DIR="$LIVE" "$NATIVE_CTL" --timeout 100ms catalog list > "$WORKDIR/lock-result" 2>&1; then
      printf '%s\n' 'Shell 快照锁未阻止 Go Catalog 读取' >&2
      return 1
    fi
    grep -Fq '"code":"command.timeout"' "$WORKDIR/lock-result" || { cat "$WORKDIR/lock-result" >&2; return 1; }
  }
  with_user_data_locks native_must_wait
  NETPROXY_MODULE_DIR="$LIVE" "$NATIVE_CTL" catalog list > "$WORKDIR/lock-result"
  grep -Fq '"ok":true' "$WORKDIR/lock-result"
)

test_installer_entrypoints() (
  ASH_STANDALONE=0
  export ASH_STANDALONE
  command -v flock >/dev/null 2>&1 || exit 0
  mocks="$WORKDIR/mocks"
  mkdir -p "$mocks"
  for name in chown chcon getevent sleep; do
    printf '#!/bin/sh\nexit 0\n' > "$mocks/$name"
  done
  printf '#!/bin/sh\nexit "${TEST_PIDOF:-1}"\n' > "$mocks/pidof"
  printf '%s\n' '#!/bin/sh' '[ -p /proc/self/fd/1 ] || exit 2' \
    '[ "$#" -eq 3 ] && [ "$1" = install ] && [ "$2" = -r ] && [ -s "$3" ]' > "$mocks/pm"
  printf '%s\n' '#!/bin/sh' '[ "$1" = -c ] || exit 1' \
    'case "$2" in */system/bin/sh*) exit 0 ;; esac' 'exec sh -c "$2"' > "$mocks/su"
  chmod +x "$mocks"/*
  PATH="$mocks:$PATH"
  export PATH
  script="$WORKDIR/customize.sh"
  sed "s@^LIVE_DIR=/data/adb/modules/netproxy@LIVE_DIR=$LIVE@;s@/dev/netproxy@$WORKDIR/state@g" "$CUSTOMIZE" > "$script"
  SCRIPT="$script"
  export SCRIPT

  run_foreground() {
    TMPDIR="$WORKDIR" MODPATH="$STAGE" ZIPFILE=fixture \
      sh -c '
        ui_print() { printf "%s\n" "$*"; }
        grep_prop() { sed -n "s/^$1=//p" "$2"; }
        unzip() {
          if [ "$3" = module.prop ]; then
            cp "$FIXTURE/module.prop" "$5/"
          else
            cp -a "$FIXTURE/." "$MODPATH/"
          fi
        }
        . "$SCRIPT"
      ' > "$WORKDIR/install-output" 2>&1
  }

  reset_modules
  FIXTURE="$WORKDIR/package"
  export FIXTURE
  cp -a "$STAGE" "$FIXTURE"
  rm -rf "$LIVE" "$STAGE"
  mkdir -p "$STAGE"
  BOOTMODE=false
  export BOOTMODE
  run_foreground
  [ ! -e "$LIVE" ]
  assert_inbound "$STAGE/config/inbound/inbound.json" package
  assert_value "$CALL_LOG" 'api init'
  [ "$(wc -l < "$CALL_LOG")" -eq 1 ]

  original_stage="$STAGE"
  STAGE="$LIVE"
  mkdir -p "$LIVE"
  run_foreground
  assert_inbound "$LIVE/config/inbound/inbound.json" package
  [ "$(grep -Fxc 'api init' "$CALL_LOG")" -eq 2 ]
  [ "$(wc -l < "$CALL_LOG")" -eq 2 ]
  if run_foreground; then exit 1; fi
  assert_inbound "$LIVE/config/inbound/inbound.json" package
  [ "$(wc -l < "$CALL_LOG")" -eq 2 ]
  STAGE="$original_stage"

  # 管理接口初始化失败时必须取消安装，不能覆盖现有模块。
  reset_modules
  TEST_API_INIT=1
  export TEST_API_INIT
  if run_foreground; then exit 1; fi
  grep -Fq '管理接口凭据初始化失败' "$WORKDIR/install-output"
  assert_value "$LIVE/module.prop" version=current
  [ -d "$STAGE" ]
  # 保留数据安装会先验证现有 Catalog，再初始化新包 API。
  [ "$(sed -n '1p' "$CALL_LOG")" = 'catalog list' ]
  grep -Fq '__internal migrate-legacy --module-dir' "$CALL_LOG"
  [ "$(sed -n '3p' "$CALL_LOG")" = 'api init' ]
  [ "$(wc -l < "$CALL_LOG")" -eq 3 ]
  unset TEST_API_INIT

  reset_modules
  run_foreground
  assert_inbound "$STAGE/config/inbound/inbound.json" current
  assert_value "$LIVE/module.prop" version=current

  reset_modules
  BOOTMODE=true TEST_CONFIG_CHECK=1 TEST_PIDOF=0
  export TEST_CONFIG_CHECK TEST_PIDOF
  if run_foreground; then exit 1; fi
  assert_value "$LIVE/module.prop" version=current
  [ -d "$STAGE" ]
  grep -q '^config check$' "$CALL_LOG"
  ! grep -q '^service stop$' "$CALL_LOG"
  ! grep -q '^__internal worker stop' "$CALL_LOG"

  reset_modules
  rm "$STAGE/bin/sing-box"
  if sh "$script" --apply-update 99999999 "$STAGE" "$LIVE" preserve; then exit 1; fi
  assert_value "$LIVE/module.prop" version=current
  [ -f "$LIVE/update" ]
  [ ! -s "$CALL_LOG" ]

  reset_modules
  # 安装器可以清理 customize.sh，后台只依赖已经打开的标准输入。
  sh -s -- --apply-update 99999999 "$STAGE" "$LIVE" preserve < "$script"
  [ ! -e "$STAGE" ] && [ ! -e "$LIVE/update" ]
  assert_inbound "$LIVE/config/inbound/inbound.json" current
  grep -q '^__internal worker start' "$CALL_LOG"
  ! grep -q '^service start$' "$CALL_LOG"
)

test_title_spacing
test_install_choices
test_key_events
test_key_output_descriptor
test_snapshot_modes
test_legacy_migration_failure
test_snapshot_failure
test_snapshot_rename_failure
test_missing_current_data
test_missing_inbound
test_missing_module
test_permissions
test_service_failures
test_hot_update
test_hot_update_guards
test_hot_update_latest_data
test_hot_rename_failure
test_linux_locks
test_native_catalog_lock
test_installer_entrypoints
printf '%s\n' 'customize hot update test passed'
