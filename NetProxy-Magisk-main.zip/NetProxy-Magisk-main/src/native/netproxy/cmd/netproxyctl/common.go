package main

import (
	"context"
	"fmt"
	"io"
	"os"
	"strings"

	json "encoding/json/v2"

	moduleconfig "github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/config"
	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/contract"
	moduleapp "github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/module"
)

func readActiveGroup(options moduleapp.Options) string {
	module, err := moduleconfig.LoadModule(options.ModuleConfig)
	if err != nil {
		return ""
	}
	return module.ActiveGroupID
}

func usageError(message string) error {
	return &resultError{Code: "usage.invalid", Message: message, Status: 2}
}

type commandHandler func(context.Context, []string) error

func (c *cli) runCommand(ctx context.Context, handler commandHandler, args ...string) int {
	if err := handler(ctx, args); err != nil {
		response, status := contract.Failure(ctx, err)
		writeJSON(os.Stdout, response)
		return status
	}
	return 0
}

func (c *cli) fail(code, message string, status int) int {
	return c.failData(code, message, map[string]any{}, status)
}

func (c *cli) failData(code, message string, data any, status int) int {
	if status <= 0 {
		status = 1
	}
	writeJSON(os.Stdout, result{Schema: 1, OK: false, Code: code, Message: message, Data: data})
	return status
}

func (c *cli) help() {
	fmt.Fprintln(os.Stdout, `NetProxy 管理命令

用法:
  netproxyctl [--json] [--timeout <秒|时长>] service status|start|stop|restart|reload|check|toggle
  netproxyctl [--json] [--timeout <秒|时长>] catalog list|show <分组>
  netproxyctl [--json] [--timeout <秒|时长>] node list|snapshot|show|get|export|delay|add|import|edit|remove
  netproxyctl [--json] [--timeout <秒|时长>] sub list|show|add|edit|update|update-all|remove|history|cancel
  netproxyctl [--json] [--timeout <秒|时长>] mode [Rule]（仅支持规则分流）
  netproxyctl [--json] [--timeout <秒|时长>] app list|mode|add|remove|enable|disable
  netproxyctl [--json] [--timeout <秒|时长>] ebpf status [configured|all|local|shared] [--raw]
  netproxyctl [--json] [--timeout <秒|时长>] config list|read|check|validate|apply
  netproxyctl [--json] [--timeout <秒|时长>] logs show|clear|export
  netproxyctl [--json] [--timeout <秒|时长>] api init|start|status|access

默认配置的出站模式:
  Rule          规则
仅支持 Rule，所有流量按 sing-box route.rules 处理。

节点仅作为 Catalog 数据维护；实际出站由 sing-box JSON 中的 Provider 与 outbounds 配置决定。
node import <文件> 会将文件中的全部节点追加到 default 本地配置组。
默认命令超时为 30 秒，service start 默认 120 秒；订阅变更由各订阅下载超时控制。
所有命令均可使用 --timeout 显式覆盖。
配置目标：singbox/config.json 为完整主配置，singbox/dns、singbox/inbounds、singbox/route 等为分区。
模块设置：module 为完整 JSON，module/auto_start 编辑开机自启。
config read 返回 revision；config apply/validate 可在目标前传 --revision <值> 检测并发修改。
分区内容保留顶层字段，例如 {"dns":{...}}；{} 删除该分区，不影响其他字段。
stdout 只包含 schema=1 结果，运行日志写入 stderr。`)
}

func writeJSON(writer io.Writer, value any) {
	if err := json.MarshalWrite(writer, value, json.Deterministic(true)); err != nil {
		return
	}
	_, _ = io.WriteString(writer, "\n")
}

func splitReference(reference string) (string, string, bool) {
	group, tag, found := strings.Cut(reference, "/")
	return group, tag, found && group != "" && tag != ""
}

func first(values []string) string {
	if len(values) == 0 {
		return ""
	}
	return values[0]
}
