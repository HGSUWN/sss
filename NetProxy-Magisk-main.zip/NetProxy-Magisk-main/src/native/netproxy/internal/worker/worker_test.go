package worker

import (
	"context"
	"encoding/json/jsontext"
	json "encoding/json/v2"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/catalog"
	moduleconfig "github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/config"
	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/provider"
	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/serviceapi"
	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/subscription"
)

type manualClock struct {
	mu     sync.Mutex
	now    time.Time
	timers []*manualTimer
	delays []time.Duration
}

func TestRetryScheduleDropsDisabledDeletedAndLocalGroups(t *testing.T) {
	for _, change := range []string{"disable", "delete", "local"} {
		t.Run(change, func(t *testing.T) {
			now := time.Now()
			root, _ := prepareWorkerFixture(t, "https://fixture.invalid", now)
			retries := map[string]subscriptionRetry{"fixture": {attempt: 1, epoch: now.Unix()}}
			path := filepath.Join(root, "fixture", "meta.json")
			if change == "delete" {
				if err := catalog.DeleteGroup(t.Context(), root, "fixture"); err != nil {
					t.Fatal(err)
				}
			} else {
				metadata, err := catalog.LoadMetadata(t.Context(), path, "fixture")
				if err != nil {
					t.Fatal(err)
				}
				if change == "disable" {
					metadata.AutoUpdate = false
				} else {
					metadata.Type = "local"
				}
				if err := catalog.SaveMetadataAtomic(t.Context(), path, metadata); err != nil {
					t.Fatal(err)
				}
			}
			schedule, err := subscriptionSchedule(t.Context(), root, now.Unix(), retries)
			if err != nil || len(retries) != 0 || len(schedule.Due) != 0 || schedule.Nearest != 0 {
				t.Fatalf("不再启用的订阅仍有重试: schedule=%+v retries=%+v err=%v", schedule, retries, err)
			}
		})
	}
}

func TestRetryScheduleDoesNotBypassBackoff(t *testing.T) {
	now := time.Now()
	root, _ := prepareWorkerFixture(t, "https://fixture.invalid", now)
	deadline := now.Add(15 * time.Minute).Unix()
	retries := map[string]subscriptionRetry{"fixture": {attempt: 1, epoch: deadline}}
	for range 3 {
		schedule, err := subscriptionSchedule(t.Context(), root, now.Unix(), retries)
		if err != nil || len(schedule.Due) != 0 || schedule.Nearest != deadline || retries["fixture"].attempt != 1 {
			t.Fatalf("重新计算调度提前重试或重置退避: %+v %v", schedule, err)
		}
	}
}

func TestSyncEditedGroupCancellationReconcilesPersistedState(t *testing.T) {
	for _, running := range []bool{false, true} {
		t.Run(fmt.Sprint(running), func(t *testing.T) {
			now := time.Now()
			root, moduleConf := prepareWorkerFixture(t, "https://fixture.invalid", now)
			path := filepath.Join(root, "fixture", "meta.json")
			metadata, err := catalog.LoadMetadata(t.Context(), path, "fixture")
			if err != nil {
				t.Fatal(err)
			}
			metadata.Name, metadata.NodeCount, metadata.RuntimeSyncState = "Renamed", 3, subscription.RuntimeSyncApplied
			if err := catalog.SaveMetadataAtomic(t.Context(), path, metadata); err != nil {
				t.Fatal(err)
			}
			options := newTestOptions(root)
			options.ModuleConfig = moduleConf
			installRuntimeHooks(t, nil, running, nil)
			options.SyncCatalog = func(ctx context.Context, _ string, changed bool) (string, bool, error) {
				if !changed {
					t.Error("名称变化未要求更新运行时结构")
				}
				if running {
					return subscription.RuntimeSyncFailed, true, ctx.Err()
				}
				return subscription.RuntimeSyncNotRunning, false, nil
			}
			ctx, cancel := context.WithCancel(t.Context())
			cancel()
			result, syncErr := SyncEditedGroup(ctx, options, "fixture", now, nil)
			after, err := catalog.LoadMetadata(t.Context(), path, "fixture")
			if err != nil || !result.Persisted || result.NodeCount != 3 {
				t.Fatalf("取消后丢失持久化结果: %+v %v", result, err)
			}
			if running {
				if syncErr == nil || !after.RuntimeSyncPending || after.RuntimeSyncState != subscription.RuntimeSyncFailed || after.LastError == "" {
					t.Fatalf("取消后未保留同步失败: %+v %v", after, syncErr)
				}
			} else if syncErr != nil || after.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
				t.Fatalf("停止状态未整理: %+v %v", after, syncErr)
			}
		})
	}
}

type manualTimer struct {
	mu      sync.Mutex
	channel chan time.Time
	fired   bool
	stopped bool
}

func newManualClock(now time.Time) *manualClock {
	return &manualClock{now: now}
}

func (clock *manualClock) Now() time.Time {
	clock.mu.Lock()
	defer clock.mu.Unlock()
	return clock.now
}

func (clock *manualClock) NewTimer(duration time.Duration) Timer {
	timer := &manualTimer{channel: make(chan time.Time, 1)}
	clock.mu.Lock()
	clock.timers = append(clock.timers, timer)
	clock.delays = append(clock.delays, duration)
	clock.mu.Unlock()
	return timer
}

func (clock *manualClock) Delays() []time.Duration {
	clock.mu.Lock()
	defer clock.mu.Unlock()
	return append([]time.Duration(nil), clock.delays...)
}

func (clock *manualClock) Advance(duration time.Duration) {
	clock.mu.Lock()
	clock.now = clock.now.Add(duration)
	timers := append([]*manualTimer(nil), clock.timers...)
	now := clock.now
	clock.mu.Unlock()
	for _, timer := range timers {
		timer.fire(now)
	}
}

func (timer *manualTimer) C() <-chan time.Time {
	return timer.channel
}

func (timer *manualTimer) Stop() bool {
	timer.mu.Lock()
	defer timer.mu.Unlock()
	if timer.fired {
		return false
	}
	timer.stopped = true
	return true
}

func (timer *manualTimer) fire(now time.Time) {
	timer.mu.Lock()
	if timer.stopped || timer.fired {
		timer.mu.Unlock()
		return
	}
	timer.fired = true
	timer.mu.Unlock()
	timer.channel <- now
}

func prepareWorkerFixture(t *testing.T, serverURL string, now time.Time) (string, string) {
	t.Helper()
	root := t.TempDir()
	groupID := "fixture"
	groupDir := filepath.Join(root, groupID)
	if err := os.MkdirAll(groupDir, 0o700); err != nil {
		t.Fatal(err)
	}
	metadata := catalog.NewMetadata(groupID, groupID, "subscription", serverURL, now)
	metadata.AutoUpdate = true
	metadata.UpdateInterval = 900
	metadata.UpdateViaProxy = "never"
	metadata.NextUpdateEpoch = now.Unix() - 1
	metadata.NextUpdateAt = catalog.FormatEpochUTC(metadata.NextUpdateEpoch)
	if err := catalog.SaveMetadataAtomic(context.Background(), filepath.Join(groupDir, "meta.json"), metadata); err != nil {
		t.Fatal(err)
	}
	if err := provider.WriteAtomic(filepath.Join(groupDir, "provider.json"), []byte(`{"outbounds":[]}`+"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	moduleConf := filepath.Join(root, "module.json")
	content := "{\"selection\":{\"group_id\":\"default\"}}"
	if err := os.WriteFile(moduleConf, []byte(content), 0o600); err != nil {
		t.Fatal(err)
	}
	return root, moduleConf
}

func waitRequest(t *testing.T, requests <-chan struct{}) {
	t.Helper()
	select {
	case <-requests:
	case <-time.After(3 * time.Second):
		t.Fatal("订阅更新请求未在限定时间内到达")
	}
}

func waitRevision(t *testing.T, path string, expected int64) {
	t.Helper()
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		metadata, err := catalog.LoadMetadata(context.Background(), path, "fixture")
		if err == nil && metadata.Revision >= expected {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("订阅 Revision 未达到 %d", expected)
}

func markStaleWorker(t *testing.T, pidFile string) {
	t.Helper()
	if err := os.WriteFile(pidFile, []byte("999999\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	lockDir := pidFile + ".lock"
	if err := os.MkdirAll(lockDir, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(lockDir, "pid"), []byte("999999\n"), 0o600); err != nil {
		t.Fatal(err)
	}
}

func installRuntimeHooks(t *testing.T, options *Options, running bool, reload func(context.Context, Options) error) {
	t.Helper()
	originalRunning, originalVerify := workerProcessRunning, workerVerifyRuntime
	workerProcessRunning = func(string) bool { return running }
	workerVerifyRuntime = func(context.Context, Options, string) error { return nil }
	if options != nil {
		syncCatalog := options.SyncCatalog
		options.SyncCatalog = func(ctx context.Context, groupID string, structureChanged bool) (string, bool, error) {
			before, err := moduleconfig.LoadModule(options.ModuleConfig)
			if err != nil {
				return currentRuntimeSyncState(*options), false, err
			}
			state, attempted, err := syncCatalog(ctx, groupID, structureChanged)
			if err != nil || !running {
				return state, attempted, err
			}
			after, err := moduleconfig.LoadModule(options.ModuleConfig)
			if err == nil && reload != nil && (structureChanged || before.ActiveGroupID != after.ActiveGroupID) {
				err = reload(ctx, *options)
			}
			return subscription.RuntimeSyncApplied, true, err
		}
	}
	t.Cleanup(func() {
		workerProcessRunning = originalRunning
		workerVerifyRuntime = originalVerify
	})
}

func installPersistenceHooks(t *testing.T, options *Options, cause error) {
	t.Helper()
	options.SyncCatalog = func(context.Context, string, bool) (string, bool, error) {
		return currentRuntimeSyncState(*options), false, cause
	}
}

func historyContains(entries []jsontext.Value, code string) bool {
	for _, entry := range entries {
		if strings.Contains(string(entry), code) {
			return true
		}
	}
	return false
}

func TestUpdateGroupWhenServiceStoppedReportsPersistedNotRunning(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"stopped-node","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_400_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	reloadCalls := 0
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err != nil {
		t.Fatalf("服务停止时订阅更新失败: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("服务停止时结果异常: %+v", result)
	}
	if reloadCalls != 0 {
		t.Fatalf("服务停止时不应调用运行时 reload: %d", reloadCalls)
	}
	if _, err := provider.Load(context.Background(), filepath.Join(root, "fixture", "provider.json")); err != nil {
		t.Fatalf("持久化 Provider 不可读: %v", err)
	}
}

func TestSyncEditedGroupReloadsAfterNameChange(t *testing.T) {
	now := time.Unix(1_700_407_000, 0)
	root, moduleConf := prepareWorkerFixture(t, "https://unused.invalid/sub", now)
	groupDir := filepath.Join(root, "fixture")
	if err := provider.WriteAtomic(filepath.Join(groupDir, "provider.json"), []byte(`{"outbounds":[{"type":"socks","tag":"edited-node","server":"127.0.0.1","server_port":1080}]}`+"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(groupDir, "meta.json"), "fixture")
	if err != nil {
		t.Fatal(err)
	}
	metadata.Name = "新的运行时名称"
	if err := catalog.SaveMetadataAtomic(context.Background(), filepath.Join(groupDir, "meta.json"), metadata); err != nil {
		t.Fatal(err)
	}
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	reloadCalls := 0
	installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})

	result, err := SyncEditedGroup(context.Background(), options, "fixture", now, nil)
	if err != nil {
		t.Fatalf("名称变更运行时同步失败: %v", err)
	}
	if !result.Persisted || !result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncApplied {
		t.Fatalf("名称变更运行时结果异常: %+v", result)
	}
	if reloadCalls != 1 {
		t.Fatalf("名称变更应触发一次 reload，实际 %d 次", reloadCalls)
	}
}

func TestSyncEditedGroupWhenServiceStoppedDoesNotReload(t *testing.T) {
	now := time.Unix(1_700_408_000, 0)
	root, moduleConf := prepareWorkerFixture(t, "https://unused.invalid/sub", now)
	groupDir := filepath.Join(root, "fixture")
	if err := provider.WriteAtomic(filepath.Join(groupDir, "provider.json"), []byte(`{"outbounds":[{"type":"socks","tag":"stopped-edit","server":"127.0.0.1","server_port":1080}]}`+"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	reloadCalls := 0
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})

	result, err := SyncEditedGroup(context.Background(), options, "fixture", now, nil)
	if err != nil {
		t.Fatalf("服务停止时编辑同步失败: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("服务停止时编辑结果异常: %+v", result)
	}
	if reloadCalls != 0 {
		t.Fatalf("服务停止时编辑不应 reload，实际 %d 次", reloadCalls)
	}
}

func TestUpdateGroupWhenServiceStoppedReturnsModuleConfigEffectError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"module-write-failure","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_405_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error { return nil })
	installPersistenceHooks(t, &options, errors.New("module.json write failed"))

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("module.json 写入失败时不应返回普通成功")
	}
	var effectErr *subscription.Error
	if !errors.As(err, &effectErr) || effectErr.Code != "subscription.persisted_effect_failed" {
		t.Fatalf("module.json 写入失败未返回结构化副作用错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("module.json 写入失败结果状态异常: %+v", result)
	}
	data, ok := effectErr.Data.(map[string]any)
	if !ok || !strings.Contains(fmt.Sprint(data["cause"]), "module.json write failed") {
		t.Fatalf("module.json 写入失败原因未保留: %#v", effectErr.Data)
	}
}

func TestUpdateGroupWhenServiceStoppedReturnsCatalogReadError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"catalog-read-failure","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_408_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error { return nil })
	installPersistenceHooks(t, &options, errors.New("Catalog read failed"))

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("Catalog 读取失败时不应返回普通成功")
	}
	var effectErr *subscription.Error
	if !errors.As(err, &effectErr) || effectErr.Code != "subscription.persisted_effect_failed" {
		t.Fatalf("Catalog 读取失败未返回结构化副作用错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("Catalog 读取失败结果状态异常: %+v", result)
	}
	data, ok := effectErr.Data.(map[string]any)
	if !ok || !strings.Contains(fmt.Sprint(data["cause"]), "Catalog read failed") {
		t.Fatalf("Catalog 读取失败原因未保留: %#v", effectErr.Data)
	}
}

func TestUpdateGroupWhenServiceStoppedEffectFailureStoresMetadata(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"effect-failure","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_407_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error { return nil })
	installPersistenceHooks(t, &options, errors.New("module.json write failed"))

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("本地副作用失败时不应返回普通成功")
	}
	var effectErr *subscription.Error
	if !errors.As(err, &effectErr) || effectErr.Code != "subscription.persisted_effect_failed" {
		t.Fatalf("本地副作用失败未返回结构化错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("本地副作用失败结果状态异常: %+v", result)
	}
	metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(metadata.LastError, subscription.PersistedEffectFailureMessage) {
		t.Fatalf("本地副作用失败未保存 last_error: %+v", metadata)
	}
	history, err := subscription.LoadHistory(filepath.Join(root, "fixture", "history.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if !historyContains(history, "subscription.persisted_effect_failed") {
		t.Fatalf("本地副作用失败未追加历史: %v", history)
	}
}

func TestUpdateGroupWhenServiceStoppedReturnsCatalogReadErrorWithMetadata(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"catalog-read-failure","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_408_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	installRuntimeHooks(t, &options, false, func(context.Context, Options) error { return nil })
	installPersistenceHooks(t, &options, errors.New("Catalog read failed"))

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("Catalog 读取失败时不应返回普通成功")
	}
	var effectErr *subscription.Error
	if !errors.As(err, &effectErr) || effectErr.Code != "subscription.persisted_effect_failed" {
		t.Fatalf("Catalog 读取失败未返回结构化错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
		t.Fatalf("Catalog 读取失败结果状态异常: %+v", result)
	}
	metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(metadata.LastError, subscription.PersistedEffectFailureMessage) {
		t.Fatalf("Catalog 读取失败未保存 last_error: %+v", metadata)
	}
	history, err := subscription.LoadHistory(filepath.Join(root, "fixture", "history.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if !historyContains(history, "subscription.persisted_effect_failed") {
		t.Fatalf("Catalog 读取失败未追加历史: %v", history)
	}
}

func TestUpdateGroupWhenServiceRunningUsesProviderWatch(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"applied-node","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_410_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	if err := os.WriteFile(moduleConf, []byte("{\"selection\":{\"group_id\":\"fixture\"}}"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := provider.WriteAtomic(filepath.Join(root, "fixture", "provider.json"), []byte(`{"outbounds":[{"type":"socks","tag":"old-node","server":"127.0.0.1","server_port":1080}]}`+"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	reloadCalls := 0
	installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err != nil {
		t.Fatalf("运行服务热重载成功时订阅更新失败: %v", err)
	}
	if !result.Persisted || !result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncApplied {
		t.Fatalf("运行服务 Provider 热更新结果异常: %+v", result)
	}
	if reloadCalls != 0 {
		t.Fatalf("已有 Provider 的普通更新不应 reload，实际 %d 次", reloadCalls)
	}
}

func TestUpdateGroupProviderWatchFailureDoesNotReload(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"new-node","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_415_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	if err := os.WriteFile(moduleConf, []byte("{\"selection\":{\"group_id\":\"fixture\"}}"), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := provider.WriteAtomic(filepath.Join(root, "fixture", "provider.json"), []byte(`{"outbounds":[{"type":"socks","tag":"old-node","server":"127.0.0.1","server_port":1080}]}`+"\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	reloadCalls := 0
	installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})
	workerVerifyRuntime = func(context.Context, Options, string) error {
		return errors.New("Provider watcher did not apply update")
	}

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("Provider 监听未应用时不应返回成功")
	}
	if result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncFailed || !result.RuntimeSyncPending {
		t.Fatalf("Provider 监听失败状态异常: %+v", result)
	}
	if reloadCalls != 0 {
		t.Fatalf("Provider 监听失败不得把普通更新升级为服务 reload: %d", reloadCalls)
	}
}

func TestRuntimeProviderMatchesRequiresExactNodeSet(t *testing.T) {
	expected := map[string]struct{}{"keep": {}}
	if !runtimeProviderMatches([]serviceapi.GroupItem{{Tag: "fixture/keep"}}, "fixture", expected) {
		t.Fatal("完全一致的 Provider 节点未通过验证")
	}
	if runtimeProviderMatches([]serviceapi.GroupItem{{Tag: "fixture/keep"}, {Tag: "fixture/drop"}}, "fixture", expected) {
		t.Fatal("包含旧节点的 Provider 被误判为已应用")
	}
	if runtimeProviderMatches([]serviceapi.GroupItem{{Tag: "other/keep"}}, "fixture", expected) {
		t.Fatal("其他 Provider 的同名节点被误判为已应用")
	}
}

func TestUpdateGroupRuntimeSyncFailureReturnsStructuredErrorAndKeepsProvider(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"failed-reload-node","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_420_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	reloadCalls := 0
	installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
		reloadCalls++
		return errors.New("Service API unavailable")
	})

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("运行时 reload 失败不应返回普通成功")
	}
	var syncErr *subscription.Error
	if !errors.As(err, &syncErr) || syncErr.Code != "subscription.runtime_sync_failed" {
		t.Fatalf("运行时失败未返回结构化错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncFailed {
		t.Fatalf("运行时失败结果异常: %+v", result)
	}
	metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
	if err != nil {
		t.Fatal(err)
	}
	if !metadata.RuntimeSyncPending || !strings.Contains(metadata.LastError, subscription.RuntimeSyncFailureMessage) {
		t.Fatalf("运行时失败未写入元数据状态: %+v", metadata)
	}
	if metadata.LastSuccessAt != now.UTC().Format(time.RFC3339) {
		t.Fatalf("运行时失败覆盖了 HTTP 更新成功时间: %q", metadata.LastSuccessAt)
	}
	history, err := subscription.LoadHistory(filepath.Join(root, "fixture", "history.jsonl"))
	if err != nil {
		t.Fatal(err)
	}
	if !historyContains(history, "subscription.runtime_sync_failed") {
		t.Fatalf("运行时失败未追加历史: %v", history)
	}
	data, ok := syncErr.Data.(map[string]any)
	if !ok || data["persisted"] != true || data["runtime_synced"] != false || data["runtime_sync_state"] != subscription.RuntimeSyncFailed {
		t.Fatalf("运行时失败错误数据不完整: %#v", syncErr.Data)
	}
	if !strings.Contains(fmt.Sprint(data["cause"]), "Service API unavailable") {
		t.Fatalf("运行时失败原因未保留: %#v", syncErr.Data)
	}
	if reloadCalls != 1 {
		t.Fatalf("运行时失败不应触发未经授权的额外 reload: %d", reloadCalls)
	}
	if _, err := provider.Load(context.Background(), filepath.Join(root, "fixture", "provider.json")); err != nil {
		t.Fatalf("运行时失败后 Provider 不可读: %v", err)
	}

	runtimeDir := filepath.Join(t.TempDir(), "runtime-after-failure")
	if err := os.MkdirAll(runtimeDir, 0o700); err != nil {
		t.Fatal(err)
	}
	runtime, err := catalog.BuildRuntime(context.Background(), catalog.RuntimeOptions{
		Root: root, ModuleConfig: moduleConf,
		ProvidersOutput: filepath.Join(runtimeDir, "providers.json"),
		OutboundsOutput: filepath.Join(runtimeDir, "outbounds.json"),
	})
	if err != nil {
		t.Fatalf("重启准备阶段无法读取最新 Provider: %v", err)
	}
	if runtime.NodeCount != 1 {
		t.Fatalf("重启准备阶段节点数异常: %+v", runtime)
	}
}

func TestUpdateGroupCancellationAfterCommitRecordsFailure(t *testing.T) {
	for _, runtimeAttempted := range []bool{false, true} {
		t.Run(fmt.Sprint(runtimeAttempted), func(t *testing.T) {
			server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
				_, _ = w.Write([]byte(`{"outbounds":[{"type":"socks","tag":"NEW","server":"127.0.0.1","server_port":1080}]}`))
			}))
			defer server.Close()
			now := time.Unix(1_700_425_000, 0)
			root, moduleConf := prepareWorkerFixture(t, server.URL, now)
			options := newTestOptions(root)
			options.ModuleConfig = moduleConf
			ctx, cancel := context.WithCancel(t.Context())
			defer cancel()
			options.SyncCatalog = func(ctx context.Context, _ string, _ bool) (string, bool, error) {
				cancel()
				return subscription.RuntimeSyncFailed, runtimeAttempted, ctx.Err()
			}
			result, err := UpdateGroup(ctx, options, "fixture", now, nil)
			wantCode, wantMessage := "subscription.persisted_effect_failed", subscription.PersistedEffectFailureMessage
			if runtimeAttempted {
				wantCode, wantMessage = "subscription.runtime_sync_failed", subscription.RuntimeSyncFailureMessage
			}
			var syncErr *subscription.Error
			if !result.Persisted || result.RuntimeSynced || !errors.As(err, &syncErr) || syncErr.Code != wantCode {
				t.Fatalf("取消后丢失已提交状态或错误分类: %+v %v", result, err)
			}
			metadata, err := catalog.PrivateMetadata(t.Context(), root, "fixture")
			if err != nil || metadata.RuntimeSyncPending != runtimeAttempted || !strings.Contains(metadata.LastError, wantMessage) || metadata.LastSuccessAt != now.UTC().Format(time.RFC3339) {
				t.Fatalf("取消后未落盘失败状态或覆盖了下载成功时间: %+v %v", metadata, err)
			}
			history, err := subscription.LoadHistory(filepath.Join(root, "fixture", "history.jsonl"))
			if err != nil || !historyContains(history, wantCode) {
				t.Fatalf("取消后未落盘失败历史: %v %v", history, err)
			}
			document, err := provider.Load(t.Context(), filepath.Join(root, "fixture", "provider.json"))
			if err != nil || len(document.Outbounds) != 1 || document.Outbounds[0].Tag != "NEW" {
				t.Fatalf("取消后丢失已提交 Provider: %+v %v", document, err)
			}
		})
	}
}

func TestUpdateGroupRuntimeVerificationFailureReturnsStructuredError(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, _ *http.Request) {
		_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"verification-failure","server":"127.0.0.1","server_port":1080}]}`))
	}))
	defer server.Close()

	now := time.Unix(1_700_425_000, 0)
	root, moduleConf := prepareWorkerFixture(t, server.URL, now)
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.SingBoxPath = filepath.Join(root, "sing-box")
	reloadCalls := 0
	installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
		reloadCalls++
		return nil
	})
	originalVerify := workerVerifyRuntime
	workerVerifyRuntime = func(context.Context, Options, string) error {
		return errors.New("Provider state was not applied")
	}
	t.Cleanup(func() { workerVerifyRuntime = originalVerify })

	result, err := UpdateGroup(context.Background(), options, "fixture", now, nil)
	if err == nil {
		t.Fatal("运行时状态验证失败时不应返回普通成功")
	}
	var syncErr *subscription.Error
	if !errors.As(err, &syncErr) || syncErr.Code != "subscription.runtime_sync_failed" {
		t.Fatalf("运行时状态验证失败未返回结构化错误: %v", err)
	}
	if !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncFailed || !result.RuntimeSyncPending {
		t.Fatalf("运行时状态验证失败结果异常: %+v", result)
	}
	if reloadCalls != 1 {
		t.Fatalf("运行时状态验证失败应只调用一次 reload，实际 %d 次", reloadCalls)
	}
	if _, err := provider.Load(context.Background(), filepath.Join(root, "fixture", "provider.json")); err != nil {
		t.Fatalf("运行时状态验证失败后 Provider 不可读: %v", err)
	}
	metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
	if err != nil {
		t.Fatal(err)
	}
	if !metadata.RuntimeSyncPending {
		t.Fatal("运行时状态验证失败后未持久化 pending 标志")
	}
}

func TestUpdateGroup304StoppedAndRunningStates(t *testing.T) {
	newServer := func(t *testing.T) *httptest.Server {
		t.Helper()
		return httptest.NewServer(http.HandlerFunc(func(writer http.ResponseWriter, request *http.Request) {
			if request.Header.Get("If-None-Match") == `"etag-v1"` {
				writer.WriteHeader(http.StatusNotModified)
				return
			}
			writer.Header().Set("ETag", `"etag-v1"`)
			_, _ = writer.Write([]byte(`{"outbounds":[{"type":"socks","tag":"etag-node","server":"127.0.0.1","server_port":1080}]}`))
		}))
	}

	t.Run("stopped", func(t *testing.T) {
		server := newServer(t)
		defer server.Close()
		now := time.Unix(1_700_430_000, 0)
		root, moduleConf := prepareWorkerFixture(t, server.URL, now)
		options := newTestOptions(root)
		options.ModuleConfig = moduleConf
		options.SingBoxPath = filepath.Join(root, "sing-box")
		reloadCalls := 0
		installRuntimeHooks(t, &options, false, func(context.Context, Options) error { reloadCalls++; return nil })
		if _, err := UpdateGroup(context.Background(), options, "fixture", now, nil); err != nil {
			t.Fatal(err)
		}
		result, err := UpdateGroup(context.Background(), options, "fixture", now.Add(time.Hour), nil)
		if err != nil {
			t.Fatal(err)
		}
		if !result.NotModified || !result.Persisted || result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncNotRunning {
			t.Fatalf("停止服务 304 结果异常: %+v", result)
		}
		if reloadCalls != 0 {
			t.Fatalf("停止服务 304 不应调用 reload: %d", reloadCalls)
		}
	})

	t.Run("running-already-synced", func(t *testing.T) {
		server := newServer(t)
		defer server.Close()
		now := time.Unix(1_700_435_000, 0)
		root, moduleConf := prepareWorkerFixture(t, server.URL, now)
		options := newTestOptions(root)
		options.ModuleConfig = moduleConf
		options.SingBoxPath = filepath.Join(root, "sing-box")
		reloadCalls := 0
		installRuntimeHooks(t, &options, true, func(context.Context, Options) error { reloadCalls++; return nil })
		if _, err := UpdateGroup(context.Background(), options, "fixture", now, nil); err != nil {
			t.Fatal(err)
		}
		result, err := UpdateGroup(context.Background(), options, "fixture", now.Add(time.Hour), nil)
		if err != nil {
			t.Fatalf("已同步运行服务 304 更新失败: %v", err)
		}
		if !result.NotModified || !result.Persisted || !result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncApplied || result.RuntimeSyncPending {
			t.Fatalf("已同步运行服务 304 结果异常: %+v", result)
		}
		if reloadCalls != 1 {
			t.Fatalf("已同步运行服务 304 不应再次 reload，实际 %d 次", reloadCalls)
		}
	})

	t.Run("running-and-retry-after-failure", func(t *testing.T) {
		server := newServer(t)
		defer server.Close()
		now := time.Unix(1_700_440_000, 0)
		root, moduleConf := prepareWorkerFixture(t, server.URL, now)
		options := newTestOptions(root)
		options.ModuleConfig = moduleConf
		options.SingBoxPath = filepath.Join(root, "sing-box")
		reloadCalls := 0
		reloadFailed := true
		installRuntimeHooks(t, &options, true, func(context.Context, Options) error {
			reloadCalls++
			if reloadFailed {
				return errors.New("temporary Service API failure")
			}
			return nil
		})
		if _, err := UpdateGroup(context.Background(), options, "fixture", now, nil); err == nil {
			t.Fatal("首次运行时同步失败应返回错误")
		}
		metadata, err := catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
		if err != nil {
			t.Fatal(err)
		}
		if !metadata.RuntimeSyncPending {
			t.Fatal("首次运行时同步失败后未持久化 pending 标志")
		}
		reloadFailed = false
		result, err := UpdateGroup(context.Background(), options, "fixture", now.Add(time.Hour), nil)
		if err != nil {
			t.Fatalf("304 重试运行时同步失败: %v", err)
		}
		if !result.NotModified || !result.Persisted || !result.RuntimeSynced || result.RuntimeSyncState != subscription.RuntimeSyncApplied {
			t.Fatalf("运行服务 304 重试结果异常: %+v", result)
		}
		if reloadCalls != 1 {
			t.Fatalf("304 可直接验证已生效的 Provider，不应再次 reload，实际 %d 次", reloadCalls)
		}
		metadata, err = catalog.LoadMetadata(context.Background(), filepath.Join(root, "fixture", "meta.json"), "fixture")
		if err != nil {
			t.Fatal(err)
		}
		if metadata.RuntimeSyncPending {
			t.Fatal("304 重试成功后未清除 pending 标志")
		}
		if metadata.LastError != "" {
			t.Fatalf("304 重试成功后未清除运行时错误: %q", metadata.LastError)
		}
		history, err := subscription.LoadHistory(filepath.Join(root, "fixture", "history.jsonl"))
		if err != nil {
			t.Fatal(err)
		}
		if !historyContains(history, "subscription.runtime_sync_failed") || !historyContains(history, "subscription.runtime_sync_applied") {
			t.Fatalf("304 重试历史不完整: %v", history)
		}
	})
}

func TestNextUpdateUsesNearestEnabledSubscription(t *testing.T) {
	root := t.TempDir()
	now := time.Unix(1_000, 0)
	for _, entry := range []struct {
		id       string
		interval int64
		auto     bool
	}{
		{id: "first", interval: 900, auto: true},
		{id: "later", interval: 3_600, auto: true},
		{id: "manual", interval: 900, auto: false},
	} {
		metadata := catalog.NewMetadata(entry.id, entry.id, "subscription", "https://example.invalid/"+entry.id, now)
		metadata.AutoUpdate = entry.auto
		metadata.UpdateInterval = entry.interval
		if entry.auto {
			catalog.ScheduleAt(&metadata, now)
		}
		group := filepath.Join(root, entry.id)
		if err := os.MkdirAll(group, 0o700); err != nil {
			t.Fatal(err)
		}
		if err := catalog.SaveMetadataAtomic(context.Background(), filepath.Join(group, "meta.json"), metadata); err != nil {
			t.Fatal(err)
		}
	}
	options := newTestOptions(root)
	options.ModuleConfig = filepath.Join(root, "module.json")
	options.Now = func() time.Time { return now }
	got, err := NextUpdate(context.Background(), root, now)
	if err != nil {
		t.Fatal(err)
	}
	if got != now.Unix()+900 {
		t.Fatalf("nearest = %d, want %d", got, now.Unix()+900)
	}
}

func TestRunExitsWhenNoAutomaticSubscription(t *testing.T) {
	root := t.TempDir()
	moduleConf := filepath.Join(root, "module.json")
	if err := os.WriteFile(moduleConf, []byte("{\"selection\":{\"group_id\":\"default\"}}"), 0o600); err != nil {
		t.Fatal(err)
	}
	options := newTestOptions(root)
	options.ModuleConfig = moduleConf
	options.PIDFile = filepath.Join(t.TempDir(), "worker.pid")
	options.Now = time.Now
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := Run(ctx, options, nil, log.New(os.Stderr, "", 0)); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(options.PIDFile); !os.IsNotExist(err) {
		t.Fatalf("PID file still exists: %v", err)
	}
}
