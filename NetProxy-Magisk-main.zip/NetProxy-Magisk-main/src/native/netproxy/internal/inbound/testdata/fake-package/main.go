package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"
	"time"
)

func main() {
	switch os.Getenv("NETPROXY_TEST_COMMAND_MODE") {

