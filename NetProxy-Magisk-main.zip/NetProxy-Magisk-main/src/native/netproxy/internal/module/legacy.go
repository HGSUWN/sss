package module

import (
	"bytes"
	"context"
	"encoding/json/jsontext"
	json "encoding/json/v2"
	"errors"
	"fmt"
	"os"
	"path/filepath"
)

// MigrateRemovedFeatures 仅在升级暂存目录中清理旧版 Wi-Fi、TUN 与遥测配置，
// 不保留这些功能的运行时实现，也不触碰 sing-box 用户主配置或 Catalog Provider。
func MigrateRemovedFeatures(ctx context.Context, options Options) error {
	if err := options.validate(); err != nil {
		return err
	}
	options, release, err := lockConfigFiles(ctx, options, options.ModuleConfig, options.InboundConfig)
	if err != nil {
		return err
	}
	defer release()
	if err := ctx.Err(); err != nil {
		return err
	}

	moduleContent, err := os.ReadFile(options.ModuleConfig)
	if err != nil {
		return fmt.Errorf("读取模块设置以清理旧字段: %w", err)
	}
	migratedModule, moduleChanged, err := migrateRemovedModuleFields(moduleContent)
	if err != nil {
		return err
	}
	inboundContent, err := os.ReadFile(options.InboundConfig)
	if err != nil {
		return fmt.Errorf("读取入站设置以清理旧字段: %w", err)
	}
	migratedInbound, inboundChanged, err := migrateRemovedInboundFields(inboundContent)
	if err != nil {
		return err
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if moduleChanged {
		if err := writeConfigAtomic(options.ModuleConfig, migratedModule, 0o600); err != nil {
			return fmt.Errorf("保存清理后的模块设置: %w", err)
		}
	}
	if inboundChanged {
		if err := writeConfigAtomic(options.InboundConfig, migratedInbound, 0o600); err != nil {
			return fmt.Errorf("保存清理后的 eBPF 入站设置: %w", err)
		}
	}
	if err := os.RemoveAll(filepath.Join(options.ModuleDir, "config", "telemetry")); err != nil {
		return fmt.Errorf("清理旧遥测状态目录: %w", err)
	}
	return nil
}

func migrateRemovedModuleFields(content []byte) ([]byte, bool, error) {
	object, err := configObject(content)
	if err != nil {
		return nil, false, fmt.Errorf("旧模块设置无效: %w", err)
	}
	changed := false
	if _, exists := object["wifi"]; exists {
		delete(object, "wifi")
		changed = true
	}
	if raw, exists := object["selection"]; exists {
		selection, err := configObject(raw)
		if err != nil {
			return nil, false, fmt.Errorf("旧 Catalog 分组设置无效: %w", err)
		}
		if _, exists := selection["node_tag"]; exists {
			delete(selection, "node_tag")
			changed = true
			object["selection"], err = json.Marshal(selection, json.Deterministic(true))
			if err != nil {
				return nil, false, err
			}
		}
	}
	if !changed {
		return content, false, nil
	}
	return marshalMigratedObject(object)
}

func migrateRemovedInboundFields(content []byte) ([]byte, bool, error) {
	object, err := configObject(content)
	if err != nil {
		return nil, false, fmt.Errorf("旧入站设置无效: %w", err)
	}
	_, hasTUN := object["tun"]
	var backend string
	if raw, exists := object["backend"]; exists {
		if err := json.Unmarshal(raw, &backend); err != nil {
			return nil, false, errors.New("旧入站 backend 字段无效")
		}
	}
	changed := false
	if hasTUN {
		delete(object, "tun")
		changed = true
	}
	if backend == "tun" {
		raw, exists := object["ebpf"]
		if !exists {
			return nil, false, errors.New("旧配置选择了 TUN，但没有保存 eBPF 参数；请先恢复 eBPF 配置")
		}
		ebpf, err := configObject(raw)
		if err != nil {
			return nil, false, fmt.Errorf("旧 eBPF 参数无效: %w", err)
		}
		local, err := configObjectOrEmpty(ebpf["local"])
		if err != nil {
			return nil, false, fmt.Errorf("旧 eBPF 本机参数无效: %w", err)
		}
		shared, err := configObjectOrEmpty(ebpf["shared"])
		if err != nil {
			return nil, false, fmt.Errorf("旧 eBPF 共享参数无效: %w", err)
		}
		localEnabled := jsonBool(local["enabled"])
		sharedEnabled := jsonBool(shared["enabled"])
		if !localEnabled && !sharedEnabled {
			local["enabled"] = jsontext.Value("true")
			ebpf["local"], err = json.Marshal(local, json.Deterministic(true))
			if err != nil {
				return nil, false, err
			}
		}
		object["ebpf"], err = json.Marshal(ebpf, json.Deterministic(true))
		if err != nil {
			return nil, false, err
		}
		object["backend"] = jsontext.Value(`"ebpf"`)
		changed = true
	}
	if !changed {
		return content, false, nil
	}
	return marshalMigratedObject(object)
}

func configObjectOrEmpty(raw jsontext.Value) (map[string]jsontext.Value, error) {
	if len(bytes.TrimSpace(raw)) == 0 || bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		return make(map[string]jsontext.Value), nil
	}
	return configObject(raw)
}

func jsonBool(raw jsontext.Value) bool {
	var value bool
	return json.Unmarshal(raw, &value) == nil && value
}

func marshalMigratedObject(object map[string]jsontext.Value) ([]byte, bool, error) {
	content, err := json.Marshal(object, json.Deterministic(true), jsontext.WithIndent("  "))
	if err != nil {
		return nil, false, err
	}
	return append(content, '\n'), true, nil
}
