package module

import (
	"os"
	"path/filepath"
	"testing"

	json "encoding/json/v2"

	moduleconfig "github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/config"
	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/inbound"
)

func TestMigrateRemovedFeaturesFromLegacySettings(t *testing.T) {
	root := t.TempDir()
	options := NewOptions(root)
	if err := os.MkdirAll(filepath.Dir(options.InboundConfig), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Dir(options.ModuleConfig), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(options.CatalogRoot, 0o700); err != nil {
		t.Fatal(err)
	}
	legacyModule := `{"auto_start":true,"selection":{"group_id":"default","node_tag":"NODE"},"wifi":{"enabled":true,"mode":"whitelist","blacklist":[],"whitelist":["Home"],"proxy_on_non_wifi":false}}`
	legacyInbound := `{"backend":"tun","root_policy":"include","app":{"enabled":false,"mode":"blacklist","proxy_apps":[],"bypass_apps":[]},"ebpf":{"type":"ebpf","tag":"netproxy-in","local":{"enabled":false},"shared":{"enabled":false}},"tun":{"type":"tun","tag":"netproxy-in","auto_route":true,"auto_redirect":true}}`
	if err := os.WriteFile(options.ModuleConfig, []byte(legacyModule), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(options.InboundConfig, []byte(legacyInbound), 0o600); err != nil {
		t.Fatal(err)
	}
	telemetry := filepath.Join(root, "config", "telemetry", "state.json")
	if err := os.MkdirAll(filepath.Dir(telemetry), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(telemetry, []byte(`{"queue":[]}`), 0o600); err != nil {
		t.Fatal(err)
	}

	if err := MigrateRemovedFeatures(t.Context(), options); err != nil {
		t.Fatal(err)
	}
	module, err := moduleconfig.LoadModule(options.ModuleConfig)
	if err != nil || !module.AutoStart || module.ActiveGroupID != "default" {
		t.Fatalf("旧模块配置未正确迁移: %+v %v", module, err)
	}
	inboundConfig, err := inbound.Load(options.InboundConfig)
	if err != nil {
		t.Fatalf("迁移后的 eBPF 配置无法读取: %v", err)
	}
	if inboundConfig.Backend != "ebpf" {
		t.Fatalf("后端没有固定为 eBPF: %s", inboundConfig.Backend)
	}
	optionsNative, err := inboundConfig.EBPFOptions()
	if err != nil {
		t.Fatal(err)
	}
	local, shared := optionsNative.EffectiveEnablement()
	if !local || shared {
		t.Fatalf("旧 TUN 配置迁移后应启用本机 eBPF: local=%t shared=%t", local, shared)
	}
	if _, err := os.Stat(filepath.Join(root, "config", "telemetry")); !os.IsNotExist(err) {
		t.Fatalf("旧遥测目录仍存在: %v", err)
	}
	var moduleDocument map[string]any
	moduleContent, _ := os.ReadFile(options.ModuleConfig)
	if err := json.Unmarshal(moduleContent, &moduleDocument); err != nil {
		t.Fatal(err)
	}
	if _, exists := moduleDocument["wifi"]; exists {
		t.Fatal("旧 Wi-Fi 设置没有删除")
	}
	selection, _ := moduleDocument["selection"].(map[string]any)
	if _, exists := selection["node_tag"]; exists {
		t.Fatal("旧节点选择字段没有删除")
	}
}

func TestMigrateRemovedFeaturesKeepsExistingEBPFPreferences(t *testing.T) {
	moduleContent := []byte(`{"auto_start":false,"selection":{"group_id":"default"}}`)
	migratedModule, changed, err := migrateRemovedModuleFields(moduleContent)
	if err != nil || changed || string(migratedModule) != string(moduleContent) {
		t.Fatalf("当前模块配置不应被改写: %s %t %v", migratedModule, changed, err)
	}
	inboundContent := []byte(`{"backend":"ebpf","root_policy":"include","app":{"enabled":false,"mode":"blacklist","proxy_apps":[],"bypass_apps":[]},"ebpf":{"type":"ebpf","tag":"netproxy-in","local":{"enabled":true},"shared":{"enabled":false}}}`)
	migratedInbound, changed, err := migrateRemovedInboundFields(inboundContent)
	if err != nil || changed {
		t.Fatalf("已是纯 eBPF 配置时不应改写: %t %v", changed, err)
	}
}
