package config

import (
	"encoding/json/jsontext"
	json "encoding/json/v2"
	"errors"
	"os"
)

type Modes struct {
	Mode      string   `json:"mode"`
	Available []string `json:"available"`
}

func LoadModes(path string) (Modes, error) {
	content, err := os.ReadFile(path)
	if err != nil {
		return Modes{}, err
	}
	return ParseModes(content)
}

func ParseModes(content []byte) (Modes, error) {
	var document map[string]jsontext.Value
	if err := json.Unmarshal(content, &document); err != nil {
		return Modes{}, err
	}
	if document == nil {
		return Modes{}, errors.New("主配置必须是 JSON 对象")
	}
	return Modes{Mode: "Rule", Available: []string{"Rule"}}, nil
}
