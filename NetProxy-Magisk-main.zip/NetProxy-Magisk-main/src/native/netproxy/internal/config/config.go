package config

import (
	"bytes"
	"context"
	"encoding/json/jsontext"
	json "encoding/json/v2"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"unicode"
	"unicode/utf8"

	"github.com/Fanju6/NetProxy-Magisk/src/native/netproxy/internal/processlock"
)

type ModuleConfig struct {
	AutoStart bool `json:"auto_start"`
	Selection `json:"selection"`
}

type Selection struct {
	ActiveGroupID string `json:"group_id"`
}

// DefaultModule 返回全新配置使用的唯一默认值集合。
func DefaultModule() ModuleConfig {
	return ModuleConfig{
		Selection: Selection{ActiveGroupID: "default"},
	}
}

func LoadModule(path string) (ModuleConfig, error) {
	content, err := os.ReadFile(path)
	if err != nil {
		return ModuleConfig{}, err
	}
	return ParseModule(content)
}

func ParseModule(content []byte) (ModuleConfig, error) {
	// JSON null 会把布尔、字符串和结构体静默置零；模块配置不允许这种隐式重置。
	decoder := jsontext.NewDecoder(bytes.NewReader(content))
	for {
		token, err := decoder.ReadToken()
		if err == io.EOF {
			break
		}
		if err != nil {
			return ModuleConfig{}, fmt.Errorf("模块 JSON 配置无效: %w", err)
		}
		if token.Kind() == 'n' {
			return ModuleConfig{}, errors.New("模块配置字段不能为 null")
		}
	}
	config := DefaultModule()
	if err := json.Unmarshal(content, &config, json.RejectUnknownMembers(true)); err != nil {
		return ModuleConfig{}, fmt.Errorf("模块 JSON 配置无效: %w", err)
	}
	return config, config.validate()
}

func (config ModuleConfig) validate() error {
	if strings.TrimSpace(config.ActiveGroupID) == "" {
		return errors.New("Catalog 管理分组 ID 不能为空")
	}
	return nil
}
