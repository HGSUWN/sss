package config

import "testing"

func TestModesAreAlwaysRule(t *testing.T) {
	for _, content := range []string{
		`{}`,
		`{"experimental":{"clash_api":{"default_mode":"Proxy"}},"route":{"rules":[{"clash_mode":["Direct","Proxy","RuleAllowAds"]}]}}`,
		`{"experimental":{"clash_api":{"default_mode":"Office"}},"dns":{"rules":[{"clash_mode":"Office"}]}}`,
	} {
		result, err := ParseModes([]byte(content))
		if err != nil || result.Mode != "Rule" || len(result.Available) != 1 || result.Available[0] != "Rule" {
			t.Fatalf("模式没有收敛到 Rule: %+v, %v", result, err)
		}
	}
}

func TestModesRejectMalformedJSON(t *testing.T) {
	for _, content := range []string{`null`, `[]`, `{`, `{"route":{},"route":{}}`, "{\"extra\":\"\xff\"}"} {
		if _, err := ParseModes([]byte(content)); err == nil {
			t.Fatalf("接受了非法配置: %s", content)
		}
	}
}
